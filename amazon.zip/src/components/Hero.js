import React from 'react';
import '../styles/Hero.css';

function Hero() {
	return (
		<div>
			<h1>hero</h1>
		</div>
	);
}

export default Hero;
